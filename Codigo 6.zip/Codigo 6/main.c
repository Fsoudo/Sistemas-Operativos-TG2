/**
 * As Crónicas de Lisboa - Versão Threads (Codigo 6 Refatorado)
 *
 * Este programa implementa o jogo usando Threads e Mutexes para
 * cumprir a recomendação de desempenho do TG2.
 *
 * Alterações:
 * - fork() -> pthread_create()
 * - Semáforos IPC -> pthread_mutex_t
 * - Memória Partilhada IPC -> Variável Global (Heap)
 */

#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

// --- DEFINICOES E CONSTANTES ---
#define MAX_NAME 50
#define MAX_DESC 200
#define MAX_CELLS 20
#define MAX_OBJECTS 5
#define NUM_MONSTERS 2

// --- ESTRUTURAS DE DADOS ---

struct Object {
  char name[MAX_NAME];
  int damage;
};

struct Monster {
  char name[MAX_NAME];
  int energy;
  int cell;
};

struct Player {
  char name[MAX_NAME];
  int energy;
  int cell;
  int object_id;
  int treasure_status;
};

struct Cell {
  int north, south, west, east;
  int object_id;
  int treasure;
  char description[MAX_DESC];
};

struct GameState {
  struct Player player;
  struct Monster monsters[NUM_MONSTERS];
  struct Cell map[MAX_CELLS];
  struct Object objects[MAX_OBJECTS];
  int nCells;
  int nObjects;
  int game_running;
};

// --- VARIAVEIS GLOBAIS ---
// Em threads, variaveis globais sao naturalmente partilhadas.
struct GameState *gamestate;

// Mutexes para sincronizacao
pthread_mutex_t mutex_gamestate = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_io = PTHREAD_MUTEX_INITIALIZER;

// Thread handle
pthread_t monster_thread;

// --- FUNCOES DE SINCRONIZACAO ---

void LockState() { pthread_mutex_lock(&mutex_gamestate); }

void UnlockState() { pthread_mutex_unlock(&mutex_gamestate); }

void LockIO() { pthread_mutex_lock(&mutex_io); }

void UnlockIO() { pthread_mutex_unlock(&mutex_io); }

// --- LIMPEZA ---

void Cleanup(int sig) {
  LockState();
  if (gamestate) {
    gamestate->game_running = 0;
  }
  UnlockState();

  // Esperar que a thread termine (se nao formos a propria thread a sair)
  // Nota: Num exit abrupto (Ctrl+C), o sistema limpa threads,
  // mas aqui podemos tentar ser elegantes.

  // Destruir Mutexes
  pthread_mutex_destroy(&mutex_gamestate);
  pthread_mutex_destroy(&mutex_io);

  if (gamestate)
    free(gamestate);

  printf("\n[SISTEMA] Jogo terminado.\n");
  exit(0);
}

// --- CARREGAMENTO ---

void LoadData() {
  FILE *f = fopen("objetos.txt", "r");
  if (f) {
    char line[100];
    while (fgets(line, sizeof(line), f)) {
      int id, dmg;
      char name[50];
      sscanf(line, "%d %s %d", &id, name, &dmg);
      if (id >= 0 && id < MAX_OBJECTS) {
        strcpy(gamestate->objects[id].name, name);
        gamestate->objects[id].damage = dmg;
        gamestate->nObjects++;
      }
    }
    fclose(f);
  }

  f = fopen("mapa.txt", "r");
  if (f) {
    int id = 0;
    char buf[200], nums[100];
    while (id < MAX_CELLS && fgets(buf, sizeof(buf), f)) {
      buf[strcspn(buf, "\r\n")] = 0;
      strcpy(gamestate->map[id].description, buf);
      if (fgets(nums, sizeof(nums), f)) {
        int n, s, e, w, u, d, obj, tr;
        sscanf(nums, "%d %d %d %d %d %d %d %d", &n, &s, &e, &w, &u, &d, &obj,
               &tr);
        gamestate->map[id].north = n;
        gamestate->map[id].south = s;
        gamestate->map[id].east = e;
        gamestate->map[id].west = w;
        gamestate->map[id].object_id = obj;
        gamestate->map[id].treasure = tr;
        id++;
      }
    }
    gamestate->nCells = id;
    fclose(f);
  }
}

void InitializeWorld() {
  LoadData();

  gamestate->player.energy = 100;
  gamestate->player.cell = 0;
  gamestate->player.object_id = -1;
  gamestate->player.treasure_status = -1;

  strcpy(gamestate->monsters[0].name, "Boss");
  gamestate->monsters[0].energy = 100;
  gamestate->monsters[0].cell = 6;

  strcpy(gamestate->monsters[1].name, "Guarda");
  gamestate->monsters[1].energy = 50;
  gamestate->monsters[1].cell = 4;

  gamestate->game_running = 1;
}

// --- OUTPUT ---

void PrintCell(int cell) {
  printf("\nLocal: %s\n", gamestate->map[cell].description);

  if (gamestate->map[cell].object_id != -1)
    printf("Item: %s\n",
           gamestate->objects[gamestate->map[cell].object_id].name);

  if (gamestate->map[cell].treasure == 1)
    printf("OBJETIVO: TESOURO!\n");

  for (int i = 0; i < NUM_MONSTERS; i++) {
    if (gamestate->monsters[i].cell == cell &&
        gamestate->monsters[i].energy > 0)
      printf("INIMIGO: %s (HP: %d)\n", gamestate->monsters[i].name,
             gamestate->monsters[i].energy);
  }
  printf("Saidas:");
  if (gamestate->map[cell].north != -1)
    printf(" N");
  if (gamestate->map[cell].south != -1)
    printf(" S");
  if (gamestate->map[cell].east != -1)
    printf(" E");
  if (gamestate->map[cell].west != -1)
    printf(" O");
  printf("\n");
}

// --- THREAD MONSTRO ---

void *MonsterLogic(void *arg) {
  // Semente aleatoria diferente para a thread
  unsigned int seed = time(NULL) ^ pthread_self();

  while (1) {
    sleep(10);

    LockState();
    if (!gamestate->game_running) {
      UnlockState();
      break;
    }

    if (gamestate->monsters[1].energy > 0) {
      int curr = gamestate->monsters[1].cell;
      int opts[] = {gamestate->map[curr].north, gamestate->map[curr].south};
      int next = opts[rand_r(&seed) % 2]; // rand_r é thread-safe
      if (next != -1)
        gamestate->monsters[1].cell = next;
    }
    UnlockState();
  }
  return NULL;
}

// --- FUNCAO DE MAPA ---

// --- FUNCAO DE MAPA REMOVIDA

// --- COMANDOS ---

void ProcessCmd(char *cmd) {
  cmd[strcspn(cmd, "\n")] = 0;

  LockState();
  int p_cell = gamestate->player.cell;

  if (strcmp(cmd, "n") == 0 && gamestate->map[p_cell].north != -1)
    gamestate->player.cell = gamestate->map[p_cell].north;
  else if (strcmp(cmd, "s") == 0 && gamestate->map[p_cell].south != -1)
    gamestate->player.cell = gamestate->map[p_cell].south;
  else if (strcmp(cmd, "e") == 0 && gamestate->map[p_cell].east != -1)
    gamestate->player.cell = gamestate->map[p_cell].east;
  else if (strcmp(cmd, "o") == 0 && gamestate->map[p_cell].west != -1)
    gamestate->player.cell = gamestate->map[p_cell].west;

  else if (strcmp(cmd, "ver") == 0) {
    UnlockState(); // Liberta antes de IO prolongado
    LockIO();
    PrintCell(p_cell);
    UnlockIO();
    return;
  } else if (strcmp(cmd, "sair") == 0) {
    UnlockState(); // Evitar deadlock no Cleanup
    Cleanup(0);
  } else if (strcmp(cmd, "apanhar") == 0) {
    if (gamestate->map[p_cell].treasure == 1) {
      gamestate->player.treasure_status = 1;
      gamestate->map[p_cell].treasure = -1;
      printf("OURO!\n");
    } else if (gamestate->map[p_cell].object_id != -1) {
      gamestate->player.object_id = gamestate->map[p_cell].object_id;
      gamestate->map[p_cell].object_id = -1;
      printf("Item apanhado.\n");
    }
  } else if (strcmp(cmd, "atacar") == 0) {
    for (int i = 0; i < NUM_MONSTERS; i++) {
      if (gamestate->monsters[i].cell == p_cell &&
          gamestate->monsters[i].energy > 0) {
        gamestate->monsters[i].energy -= 10;
        printf("Hit %s!\n", gamestate->monsters[i].name);
      }
    }
  }

  UnlockState();
}

// --- MAIN (THREAD JOGADOR) ---

int main() {
  signal(SIGINT, Cleanup);

  // Alocação Heap (ja nao e Shared Memory)
  gamestate = (struct GameState *)malloc(sizeof(struct GameState));
  if (!gamestate) {
    perror("Malloc falhou");
    exit(1);
  }
  memset(gamestate, 0, sizeof(struct GameState));

  // Inicializacao
  InitializeWorld();

  LockIO();
  printf("Nome: ");
  UnlockIO();

  char buf[50];
  fgets(buf, 50, stdin);

  // Criar Thread do Monstro
  if (pthread_create(&monster_thread, NULL, MonsterLogic, NULL) != 0) {
    perror("Falha ao criar thread");
    Cleanup(1);
  }

  // Loop Principal (Jogador)
  while (1) {
    LockState();

    // Vitoria
    if (gamestate->player.treasure_status == 1 && gamestate->player.cell == 0) {
      UnlockState();
      printf("\n\n*** VITORIA! CONSEGUISTE ESCAPAR COM O TESOURO! ***\n");
      printf("[Pressiona Enter para continuar...]\n");
      char dummy[10];
      fgets(dummy, 10, stdin);

      LockState();
      gamestate->game_running = 0;
      UnlockState();
      break;
    }

    if (!gamestate->game_running) {
      UnlockState();
      printf("\n\n*** GAME OVER! ***\n");
      break;
    }

    if (gamestate->player.energy <= 0) {
      UnlockState();
      printf("\n\n*** A TUA ALMA PERDEU-SE NA ESCURIDAO... ***\n");
      LockState();
      gamestate->game_running = 0;
      UnlockState();
      break;
    }

    int c = gamestate->player.cell;
    UnlockState();

    LockIO();
    PrintCell(c);
    printf("[Comandos: n, s, e, o, ver, apanhar, atacar, sair]\n");
    printf("> ");
    fflush(stdout);
    UnlockIO();

    // Leitura bloqueante (segura pois IO nao esta trancado)
    if (!fgets(buf, 50, stdin))
      break;
    ProcessCmd(buf);
  }

  // Esperar fim da thread monstro
  pthread_join(monster_thread, NULL);
  Cleanup(0);
  return 0;
}
